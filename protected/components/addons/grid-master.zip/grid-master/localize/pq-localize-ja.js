/**
 * @author pdhindsa
 */
$.paramquery.pqGrid.regional['ja'] = {
	strLoading: "読込中",
	strAdd: "追加",
	strEdit: "編集",
	strDelete: "削除",
	strSearch: "検索",
	strNothingFound: "データが見つかりませんでした",
	strSelectedmatches:"前の結果",
	strPrevResult: "次の結果",
	strNextResult: "データがありません"	
}
$.paramquery.pqPager.regional['ja']={
	strPage:" {0} / {1} ページ",
	strFirstPage:"先頭ページ",
	strPrevPage:"前ページ",
	strNextPage:"次ページ",
	strLastPage:"最終ページ",
	strRefresh:"再読み込み",	
	strRpp:"1ページの件数:",
	strDisplay:"{2} 件中 {0}-{1}件"	
}
